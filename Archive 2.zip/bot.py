import random
from game_message import *


class Bot:
    def __init__(self):
        print("Initializing nutrient-hungry bot")
        random.seed()

    def _manhattan(self, a: Position, b: Position) -> int:
        return abs(a.x - b.x) + abs(a.y - b.y)

    def _nearest_target(self, start: Position, candidates: list[Position]) -> Position | None:
        if not candidates:
            return None
        best = min(candidates, key=lambda p: abs(p.x - start.x) + abs(p.y - start.y))
        return best

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        """
        Here is where the magic happens, for now the moves are not very good. I bet you can do better ;)
        """
        actions: list[Action] = []

        world = game_message.world
        my_team: TeamInfo = world.teamInfos[game_message.yourTeamId]

        # Defensive: if no spores and no spawners, nothing to do
        if (not my_team.spores) and (not my_team.spawners):
            return actions

        width = world.map.width
        height = world.map.height

        # Build candidate tiles: prefer tiles not owned by us and tiles with nutrients
        # Score tiles by nutrient and distance; we'll pick high-scoring nearby tiles
        candidates: list[tuple[Position, int]] = []
        for y in range(height):
            for x in range(width):
                owner = world.ownershipGrid[y][x]
                nut = world.map.nutrientGrid[y][x]
                if owner != my_team.teamId or nut > 0:
                    # use nutrient as base score; higher is better
                    candidates.append((Position(x=x, y=y), nut))

        # If we have spawners and nutrients, consider producing a spore
        # Be conservative: only produce when nutrients are sufficient and we don't already have many spores
        if my_team.spawners and my_team.nutrients >= 5 and len(my_team.spores) < 6:
            # produce a modest spore to expand
            biomass_to_produce = min(10, my_team.nutrients)
            if biomass_to_produce >= 1:
                actions.append(
                    SpawnerProduceSporeAction(
                        spawnerId=my_team.spawners[0].id, biomass=biomass_to_produce
                    )
                )

        # If we have spores, assign each to a target
        # Helper to pick best candidate for a spore based on score = nutrient - distance penalty
        def pick_best_target(spore: Spore) -> Position | None:
            if not candidates:
                return None
            best_pos = None
            best_score = -10_000_000
            for pos, nut in candidates:
                dist = self._manhattan(spore.position, pos)
                # Penalize distance and favor nutrients. Add small bias for unowned tiles.
                owner = world.ownershipGrid[pos.y][pos.x]
                owner_bonus = 5 if owner != my_team.teamId else 0
                score = nut * 10 + owner_bonus - dist
                if score > best_score:
                    best_score = score
                    best_pos = pos
            return best_pos

        for spore in list(my_team.spores):
            # Skip spores that cannot act (static)
            if spore.biomass < 2:
                continue

            target = pick_best_target(spore)

            # If no target, move randomly if spore is mobile
            if target is None:
                actions.append(
                    SporeMoveToAction(
                        sporeId=spore.id,
                        position=Position(
                            x=random.randint(0, width - 1),
                            y=random.randint(0, height - 1),
                        ),
                    )
                )
                continue

            # If we have no spawners, consider creating one only if spore has enough biomass
            # and the current tile is reasonably valuable
            cur_x = spore.position.x
            cur_y = spore.position.y
            cur_nut = world.map.nutrientGrid[cur_y][cur_x]
            if (not my_team.spawners) and spore.biomass >= max(1, my_team.nextSpawnerCost) and cur_nut >= 1:
                actions.append(SporeCreateSpawnerAction(sporeId=spore.id))
                continue

            # Movement rules: moving to empty tile costs 1 biomass, moving on own trail costs 0.
            dest_owner = world.ownershipGrid[target.y][target.x]
            dest_biomass = world.biomassGrid[target.y][target.x]
            is_own_trail = dest_owner == my_team.teamId and dest_biomass > 0
            dest_nut = world.map.nutrientGrid[target.y][target.x]

            # Avoid moving very-low-biomass spores onto empty tiles unless nutrient payoff is high
            will_cost = 0 if is_own_trail else 1
            if will_cost == 1 and spore.biomass <= 2 and dest_nut < 20:
                # Skip movement to avoid making the spore static; instead, pick a different target or wait
                # Try to find alternate target that is own trail or high nutrient
                alt = None
                for pos, nut in candidates:
                    owner = world.ownershipGrid[pos.y][pos.x]
                    biomass_here = world.biomassGrid[pos.y][pos.x]
                    if owner == my_team.teamId and biomass_here > 0:
                        alt = pos
                        break
                if alt:
                    actions.append(SporeMoveToAction(sporeId=spore.id, position=alt))
                # otherwise, do nothing this tick to preserve biomass
                continue

            # Otherwise, move towards selected target
            actions.append(SporeMoveToAction(sporeId=spore.id, position=target))

        return actions
