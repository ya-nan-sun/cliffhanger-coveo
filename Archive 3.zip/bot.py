import random
from game_message import *


class Bot:
    def __init__(self):
        print("Initializing nutrient-hungry bot")
        random.seed()

    def _manhattan(self, a: Position, b: Position) -> int:
        return abs(a.x - b.x) + abs(a.y - b.y)

    def _nearest_target(self, start: Position, candidates: list[Position]) -> Position | None:
        if not candidates:
            return None
        best = min(candidates, key=lambda p: abs(p.x - start.x) + abs(p.y - start.y))
        return best

    def get_next_move(self, game_message: TeamGameState) -> list[Action]:
        # New behavior: find tiles with nutrients (map.nutrientGrid>0) and assign spores to claim them.
        actions: list[Action] = []

        world = game_message.world
        my_team: TeamInfo = world.teamInfos[game_message.yourTeamId]

        used_spore_ids: set[str] = set()
        used_spawner_ids: set[str] = set()

        # Debug: print current spores (id, position, biomass) for easier tracing
        try:
            spores_info = ", ".join(
                f"{s.id}@({s.position.x},{s.position.y})=b{s.biomass}" for s in my_team.spores
            ) if my_team.spores else "(no spores)"
            print(f"Team {my_team.teamId} spores: {spores_info}")
        except Exception:
            pass

        width = world.map.width
        height = world.map.height

        # collect nutrient tiles that are not owned by us
        nutrient_tiles: list[Position] = []
        for y in range(height):
            for x in range(width):
                nut = world.map.nutrientGrid[y][x]
                owner = world.ownershipGrid[y][x]
                if nut > 0 and owner != my_team.teamId:
                    nutrient_tiles.append(Position(x=x, y=y))

        # Debug: show a few nutrient targets we will consider (should be non-owned)
        try:
            if nutrient_tiles:
                sample = nutrient_tiles[:10]
                detail = ", ".join(f"({p.x},{p.y})={world.map.nutrientGrid[p.y][p.x]}" for p in sample)
                print(f"Found {len(nutrient_tiles)} nutrient tiles (non-owned). Sample: {detail}")
            else:
                print("No non-owned nutrient tiles found this tick.")
        except Exception:
            pass

        # Produce spores at spawners near nutrient tiles if we have nutrients
        remaining_nutrients = my_team.nutrients
        if my_team.spawners and remaining_nutrients >= 1 and nutrient_tiles:
            # sort spawners by distance to closest nutrient tile
            def spawner_score(sp: Spawner) -> int:
                return min(self._manhattan(sp.position, p) for p in nutrient_tiles)

            spawners_sorted = sorted(my_team.spawners, key=spawner_score)
            for sp in spawners_sorted:
                if remaining_nutrients <= 0:
                    break
                if sp.id in used_spawner_ids:
                    continue
                # produce a modest spore sized to available nutrients but keep some reserve
                produce_amt = min(10, remaining_nutrients)
                if produce_amt >= 1:
                    actions.append(SpawnerProduceSporeAction(spawnerId=sp.id, biomass=produce_amt))
                    used_spawner_ids.add(sp.id)
                    remaining_nutrients -= produce_amt

        # if no nutrient tiles, fallback to moving toward any non-owned tile
        non_owned_tiles: list[Position] = []
        for y in range(height):
            for x in range(width):
                owner = world.ownershipGrid[y][x]
                if owner != my_team.teamId:
                    non_owned_tiles.append(Position(x=x, y=y))

        # mobile spores
        mobile_spores = [s for s in my_team.spores if s.biomass >= 2]
        if not mobile_spores:
            return actions

        # Assign each mobile spore to a unique target tile (prefer nutrient tiles)
        assigned: set[tuple[int, int]] = set()

        def cardinal_step_towards(src: Position, dst: Position) -> Position:
            dx = dst.x - src.x
            dy = dst.y - src.y
            if abs(dx) >= abs(dy) and dx != 0:
                step = Position(x=src.x + (1 if dx > 0 else -1), y=src.y)
            elif dy != 0:
                step = Position(x=src.x, y=src.y + (1 if dy > 0 else -1))
            else:
                step = Position(x=src.x, y=src.y)
            return step

        # Work with copies so we can pop assigned targets
        nutrient_targets = list(nutrient_tiles)
        # sort nutrient targets by nutrient value descending to prioritise high-value tiles
        nutrient_targets.sort(key=lambda p: world.map.nutrientGrid[p.y][p.x], reverse=True)

        remaining_spores = sorted(mobile_spores, key=lambda s: s.biomass, reverse=True)

        # First: assign at most one spore per nutrient tile (highest-value tiles first)
        for target in list(nutrient_targets):
            if not remaining_spores:
                break
            # pick the closest available spore to this target
            best_spore_idx = None
            best_dist = 10_000_000
            for i, s in enumerate(remaining_spores):
                if s.id in used_spore_ids:
                    continue
                d = self._manhattan(s.position, target)
                if d < best_dist:
                    best_dist = d
                    best_spore_idx = i

            if best_spore_idx is None:
                continue

            spore = remaining_spores.pop(best_spore_idx)
            # reserve target
            assigned.add((target.x, target.y))

            # determine if moving to target would make this spore static (arrive with 1 biomass)
            dest_owner = world.ownershipGrid[target.y][target.x]
            dest_biomass = world.biomassGrid[target.y][target.x]
            is_own_trail = dest_owner == my_team.teamId and dest_biomass > 0
            will_cost = 0 if is_own_trail else 1
            if will_cost == 1 and spore.biomass - will_cost <= 1 and spore.biomass >= 3:
                biomass_for_mover = max(2, spore.biomass // 2)
                step = cardinal_step_towards(spore.position, target)
                actions.append(
                    SporeSplitAction(
                        sporeId=spore.id,
                        biomassForMovingSpore=biomass_for_mover,
                        direction=Position(x=step.x - spore.position.x, y=step.y - spore.position.y),
                    )
                )
                used_spore_ids.add(spore.id)
            else:
                actions.append(SporeMoveToAction(sporeId=spore.id, position=target))
                used_spore_ids.add(spore.id)

            # remove this nutrient target from the pool
            try:
                nutrient_targets.remove(target)
            except ValueError:
                pass

        # Second: assign remaining spores to other non-owned tiles (unique per spore)
        other_targets = [p for p in non_owned_tiles if (p.x, p.y) not in assigned]

        for spore in remaining_spores:
            if spore.id in used_spore_ids:
                continue
            # pick nearest other target if available
            best_idx = None
            best_dist = 10_000_000
            for i, p in enumerate(other_targets):
                d = self._manhattan(spore.position, p)
                if d < best_dist:
                    best_dist = d
                    best_idx = i
            if best_idx is not None:
                target = other_targets.pop(best_idx)
                assigned.add((target.x, target.y))
                dest_owner = world.ownershipGrid[target.y][target.x]
                dest_biomass = world.biomassGrid[target.y][target.x]
                is_own_trail = dest_owner == my_team.teamId and dest_biomass > 0
                will_cost = 0 if is_own_trail else 1
                if will_cost == 1 and spore.biomass - will_cost <= 1 and spore.biomass >= 3:
                    biomass_for_mover = max(2, spore.biomass // 2)
                    step = cardinal_step_towards(spore.position, target)
                    actions.append(
                        SporeSplitAction(
                            sporeId=spore.id,
                            biomassForMovingSpore=biomass_for_mover,
                            direction=Position(x=step.x - spore.position.x, y=step.y - spore.position.y),
                        )
                    )
                    used_spore_ids.add(spore.id)
                else:
                    actions.append(SporeMoveToAction(sporeId=spore.id, position=target))
                    used_spore_ids.add(spore.id)
            else:
                # no candidate targets left; pick a random unassigned tile
                attempts = 0
                while attempts < 20:
                    tx = random.randint(0, width - 1)
                    ty = random.randint(0, height - 1)
                    if (tx, ty) not in assigned:
                        target = Position(x=tx, y=ty)
                        break
                    attempts += 1
                else:
                    target = Position(x=random.randint(0, width - 1), y=random.randint(0, height - 1))
                actions.append(SporeMoveToAction(sporeId=spore.id, position=target))
                used_spore_ids.add(spore.id)
                assigned.add((target.x, target.y))

        # Debug
        try:
            print(f"Tick {game_message.tick}: scheduled {len(actions)} actions to nutrient tiles={len(nutrient_tiles)}")
            for a in actions:
                if isinstance(a, SporeMoveToAction):
                    print(f"  SporeMoveTo spore={a.sporeId} -> ({a.position.x},{a.position.y})")
        except Exception:
            pass

        return actions
